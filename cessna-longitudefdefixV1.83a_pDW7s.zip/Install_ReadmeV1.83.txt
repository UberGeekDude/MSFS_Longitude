Asobo Cessna Citation Model 700 Longitude Performance and Flight Dynamics Modifications Project Version 1.83

Please check out the chatter and follow the progress for this project on the offical MSFS 2020 Forum:
https://forums.flightsimulator.com/t/cessna-citation-longitude-flight-dynamics-modification-project

Version 1.83 Changes:

-Restores compatibility with March 9 2021 Asobo update. The mod should work for all users once the Asobo update is installed.
-Important note 1: As of the March 9 update, older versions of Working Title G3000 suite are not compatible with the default Longitude or with the modified version (I have not tested their most recent version). Revert to default avionics (remove Working Title G3000 modifications) until Working Title has an update available that is compatible.
-Important note 2: Asobo have implemented a mach meter and mach hold setting indicator in the PFD speed tape. They have also fixed the Mach Hold functionality to work properly as altitude changes. These are welcome fixes / improvements. However, the barber pole in the speed tape is now further bugged and is now tied to the Mach meter transition speed (transition between True Airspeed indication and Mach). This is set to Mach 0.78 in the mod (0.79 in Asobo's latest update). This means that once transitioned to Mach readout above approximately Mach 0.78, your airspeed will be in the red. There is no clear fix for this other than doing away with the mach meter except when above Mmo overspeed (Mach 0.84). I've elected to leave this alone for now so we have a functional Mach meter and hope that Asobo will correct in a future update.

Version 1.82 Changes:

-Resolves an Asobo introduced error in the panel.cfg file used to address gear alerts and altitude callouts causing tail registration number to not display correctly.
-Resolves issues for users who previously installed 1.81 and for whom the Longitude subsequently didn't load into the aircraft selection menu. 

Version 1.81 Changes:

-Reverts flaps lift coefficient back to prior value in response to March 02 2021 hotfix. 

Version 1.80 Changes:

-Significant changes to engine parameters to achieve improved, "on the numbers", climb performance at various aircraft weights. Aircraft should follow Cessna spec climb profiles (300 IAS to intercept Mach 0.8 - 457 to 460 KIAS for high speed climb, for example). The aircraft should be able to intercept M0.8 and hold this speed for a climb of approx. 23 minutes to FL430 at MTOW and 16 minutes to FL430 at a takeoff weight of 33k lbs. Climb profile used in Cessna's testing for high speed climb is 290 KIAS to 10k feet (unrestricted climb), 300 KIAS to intercept with M0.8 (at approx. FL300) and hold M0.8 to cruise altitude.   

-Adjusted engine thrust output as a function of N1 to bring this much closer to real world published N1 / performance results. The range of N1 values needed to maintain specific airspeeds, in particular at cruise, is quite narrow. This update improves performance to replicate this more narrow band of N1 vs thrust performance. 

-Adjusted PID values for autothrottle to improve speed capture and hold speeds in general and with narrower N1 / thrust banding. There will be more/faster throttle lever movements and adjustments, especially at lower altitudes and airspeeds. This is somewhat experimental at this time.   

-Adjusted aircraft lift paramaters to bring aircraft closer to real world V-speeds.

-Further adjustments to stall speed boundaries and aoa limits. However, achieving realistic stall performance at the manufacturer tested speeds has not been possible without disrupting other significant aspects of aicraft performance - the sim doesn't read all values in the lift coeffiecient aoa table entries which makes this effort somewhat limited.

-Slightly increased elevator authority to increase pitch control, especially at lower speeds like during takeoff and approach. 

-Corrected flaps lift coefficient after Asobo update from Feb. 16, 2021. 

-Corrected missing altitude alert callouts in OnAir version.


*Please see version notes below for a list of all changes made since project inception.


//_________________________________________________________________________________________

Installation*:

New Installation or Upgrade Installation From V1.2 through V1.82 - Standard Version**:
1. Strongly recommend backing up all of your default Asobo Longitude files in the \Packages\Official\OneStore\asobo-aircraft-longitude, especially the default Asobo layout.json file. Save this backup somewhere else besides the Official content folder - copies of the a/c files in this folder will cause problems with your software.
2. Over-write the "layout.json" file in the LocalCache\Packages\Official\OneStore\asobo-aircraft-longitude directory with the included new layout.json file I've provided.
3. Copy the "aircraft-longitudefdefix" Folder into your \LocalCache\Packages\Community folder. Remove prior version files if they exist (preferred) or overwrite prior version files, if applicable, when prompted.
4. If applicable (V1.3 installs only), remove my prior landing and taxi lighting enhancements folder "Landing-Taxi Lights Enhancement" (if you prefer the Asobo defaults). This will not prevent you from enjoying the upgraded lighting included with this mod package.  
5. Go flying!

New Installation or Upgrade Installation From V1.2 through V1.82 - OnAir Virtual Airline Version**:
1. Strongly recommend backing up all of your default Asobo Longitude files in the \Packages\Official\OneStore\asobo-aircraft-longitude, especially the default Asobo layout.json file.
2. Over-write the "layout.json" file in the LocalCache\Packages\Official\OneStore\asobo-aircraft-longitude directory with the included new layout.json file I've provided.
3. IMPORTANT: Remove prior Longiude modification packages or you will have conflicts between prior version and the OnAir version.
4. Copy the "aircraft-longitudefdefix_OnAir" Folder into your \LocalCache\Packages\Community folder. 
5. If applicable, remove my prior landing and taxi lighting enhancements folder "Landing-Taxi Lights Enhancement" (if you prefer the Asobo defaults). This will not prevent you from enjoying the upgraded lighting included with this mod package.  
6. Go flying!

If you've previously installed V1.1 or V1.0 and have not updated since, some cleanup is needed before installation of  V1.83:
1. In your \LocalCache\Packages\Official\OneStore\asobo-aircraft-longitude\SimObjects\Airplanes\Asobo_Longitude folder remove the following files if they exist:
-aicraft.cfg
-systems.cfg
-engines.cfg
-flight_model.cfg
2. Remove the entire Asobo_Longitude-DynamicsFixV1 Folder from your \LocalCache\Packages\Community folder, if it exists 
3. Go to the New Installation instructions above.

*After proper installation, when Livery selections are made in the aircraft selection menu options for the Longitude, the Longitude will display the following in the variant area: "FDE Fix V1.83" or "FDE Fix V1.83 OnAir" depending on installation package you choose. This will help you quickly identify whether installation of the package was successful and identify package version - this will only affect the default Asobo livery listing and not other liveries, however the performance modifications will be applied to all Longitude liveries you've installed.

**You may only install one version (Standard or OnAir) at a time. If both are installed only one or the other will be available to you in the aircraft selection menu. If you have previously installed any prior standard Longitude modification package version up through 1.82, you must remove those files from the Community folder before installing the OnAir version and vice versa if OnAir was previously installed.

FAILED INSTALLATION NOTES:
Installs occasionally fail and the Longitude will no longer be visible in the aircraft selection menu. A common fix is to close the sim, remove the mod package, restart the sim and then in the content manager within the sim, delete and then reinstall the stock Longitude. Once the stock Longitude is confirmed available, close the sim and reinstall the mod as instructed above. Restart the sim and check to see if the modded version is now available. 

Future Asobo Update / Patch Note:
Each time Asobo makes future updates the default Longitude files, the layout.json file will be over-written in the Official Longitude file set. This will prevent this modification package from working. I will endeavour to post updates as soon as possible after each successive update from Asobo, so you can continue to enjoy my modifications project. There is presently no way to avoid having to over-write the default layout.json in the Official folder and have these files work as desired. 


//_________________________________________________________________________________________

The Cessna Citation Model 700 Longitude Performance and Flight Dynamics Modifications Project:
After reading user comments on the forums regarding the Cessna Citation Longitude model from Asobo concerning major autopilot problems, inaccurate weights, fuel load, fuel consumption, handling, etc... and due to my own poor experience and frustration with Asobo's starting efforts, I started work on revising a wide variety of parameters in the configuration files borrowed from the Cessna CJ4 model, modified to match the real world specifications for the Longitude as closely as possible. I also modified the default layout.json file for the Longitude to bypass the encrypted configuration files and point to copied and modified versions of non-encrypted files borrowed from the CJ4. These files have all been heavily modified and with a fair amount of guesswork I've been able to produce a working version of the Longitude that is more docile in handling and produces performance numbers that much more closely match the real-world specs for the Longitude. I'm not a Longitude pilot, so my modifications are based on comments on forum topics from those who fly the type, and generous contributions of real world C700 aircraft performance charts, flight manuals, and checklists from fellow flight-sim enthusiasts who also fly IRL for a living. Input from type-rated pilots with knowledge of the aircraft handling and envelope will always be greatly valued. My adjustments are generally focused on performance and handling. Any issues with the G5000 suite and avionics in general are not the subject of this modification. If Asobo chooses to decrypt the xml files associated with the type, a motivated person could presumably start modifying and improving the avionics suite much like has been done with the CJ4 and other un-encrypted aircraft. 

I have modified a great many variables and parameters in the available configuration files. I would greatly appreciate feedback on handling, control sensitivies, or other performance related parameters from knowledgable sources so I can continue to improve and update these modifications. If I missed something or you find a performance "glitch" please let me know.



//_________________________________________________________________________________________


Open flight behavior and performance items for possible future consideration and/or correction:
-Known issue with altitude alert call-outs and landing gear warning fix and third party liveries for the Longitude. This feature / update works with some liveries and not others.
-Post-stall and low angle of attack handling (ongoing). The aircraft continues to fly well into the stall. This could be addressed with high alpha handling adjustments to reduce control and potentially introduce instability. IRL the aircraft uses a stick shaker and pusher to force the a/c away from stall as well as increases throttle. This is not modeled by Asobo and is not a target for modification within the files accessible at this time. 
-Investigate eliminating throttle angle "dead space" when above max N1/N2.
-Realistic hydraulic system modeling is not incorporated into the Asobo model.
-Continue to investigate autopilot VS hold mode characteristics - attempt to further reduce overshoot issues when autopilot is seeking correct vertical speed rate. Presently it overshoots a little and then corrects, causing the aircraft pitch to oscillate slightly. The ai.cfg PID tables may ultimately hold the key, but after much trial and error, I haven't been able to get this to smooth out completely without degrading autopilot altitude hold performance. 
-Continue to investigate and refine autothrottle functioning. Still over or undershoots in some scenarios. 

Significant avionics issues (there are others, but these are most commonly noted) that I don't have file access to address, but maybe someday Asobo will unlock...
-FLC MACH bug - FLC does not properly adjust Mach setting as aircraft climbs in the upper flight levels. 
-Localizer approach hold and other precision approach related autopilot and avionics functions. 
-Gallons displayed on MFD vs. pounds. Could not solve using current file access.
-Auto-ground spoilers should set to Norm by default (instead of disarm). Could not solve using current file access.
-Cabin altitude is incorrect (too high) at cruise alt. Could not solve using current file access.
-Lighting controls don't correctly correspond to IRL a/c lighting system, which is controlled from both the overhead light switches and in the G5000 menus. Could not solve using current file access.
-Annunciator system is not functioning accurately. 
-G5000 is missing many functions and capabilities present IRL.
-Live Weather appears to be bugged and causing problems with engine performance that are not consistent with real world affects of temperature and pressure, as well as affecting the MMo "barber pole" tape - reporting overspeed conditions when the aircraft is well below M0.84.


//_________________________________________________________________________________________

Prior Version Change Log:

Version 1.75 Changes:

-Fix is incorporated for problem with reverser sound coming on during flight. Was achieved by adjusting minimum idle N1 value to 28%, without any knock-on effect on aircraft performance.

-Fixed low N1 power band (between 2x% and 60%) to provide more thrust control at low N1 values resulting in improvements to taxi and pattern power settings.

-Fixed issue with engine spoolup time being too quick and resulting in oscillations around target N1 value.

-Added altitude alert callouts from 500 feet to 50 feet when descending on approaches. 500, 400, 300, 200, 100, and 50 are modeled. Additional callouts may be possible by using third party mods available and may be included in subsequent release.

-Adjusted high angle of attack lift coefficients to produce more reasonable stall performance. There are some interesting and inconsistent Asobo modeling behaviors in this part of the modeled flight envelope and as such I will consider this modification to be experimental at this time. Further investigation and testing may yield further improvements and refinements. With this version, the aircraft aoa needle will enter the red zone and the stall aural alert will sound several knots before the target stall speed for a given flaps and weight configuration is reached (prior versions would sound the stall alert as soon as the aoa arrow entered the red and at the target stall speed). As speed bleeds off and speed hits the target stall speed for the given configuration the aoa needle will be at the limit of the aoa meter. At stall speed, the aircraft will either continue to fly into the stall as airspeed decays or it may abruptly drop the nose or wing over (preferred behavior). In testing I have seen both behaviors with no explanation for why one or the other occurs, and I will continue to explore further to determine why the inconsistency occurs and attempt to finalize a build with a correct stall speed and behavior set. 


Version 1.70 Changes:

-Activated a new variable allowing for reversion to prior sim (FSX era) turbine engine modeling. Allows for far more accurate modeling of fuel consumption and thrust with increasing altitude. This solves the ongoing problem of the missing lapse rate for fuel consumption with decreasing air density in Asobo's new turbine engine modeling. Also resolves unrealistic engine temperature and N2 values that were a consequence of the efforts to optimize fuel consumption at cruise. A/C will now show decreasing fuel consumption with increasing altitude for a given Mach number. Model also shows an increasing fuel consumption as aircraft increases Mach number (prior versions showed an inverse relationship, which is not accurate). Additionally, the aircraft will now burn fuel at near spec during low altitude flight. Does not resolve prior issues with engine overspeed (lack of a FADEC model) while at maximum throttle and while using auto-throttle. You'll still have to manage your engines to avoid redline. 

Version 1.60 Changes:
 
-Increased N1 maximum limit slightly and adjusted Mach drag curve between M0.78 and M0.80 to improve climb performance when using high speed or cruise climb profiles. Now the a/c will climb at 270 or 300 KIAS (using FLC mode) until intercepting approx 455 TAS and by switching over to VS hold (the Asobo Mach hold for the Longitude is bugged so FLC won't work correctly with Mach hold) to manually maintain this airspeed until reaching cruise altitude you can reach FL430 at MTOW in approx. 23 minutes, and at 32K lbs takeoff weight, in approx 16 minutes. This will approximate real world time to climb performance very closely. These changes will, however, allow for a higher N1 value (by about 1%) than is allowed by the FADEC in real life, and at low altitude and full throttle, the engine will exceed N1 redline slightly so watch your throttle. At cruise altitude (above FL400) and maximum continuous thrust, allowed N1 is just under 90%. To maintain fidelity in your simulated flights, please consider keeping N1 values below 90% at cruise altitude. 

-Credit to GBTAW (Tim Wright) for finding a solution to the landing gear alerting function. This has now been corrected to eliminate erroneous "landing gear" audible warnings. "Landing Gear" audible alert will no longer sound when at idle thrust in flight or at flaps 2 setting and landing gear up. Will only alert when flaps 3 is selected and gear is not down. 

-Lighting improvements from Uwajimaya
	-adjusted brightness of beacons
	-adjusted timing of red/white flashes for further accuracy

-Adjusted VS hold selection increments to 50 ft from 100 ft.

-Incorporated a handful of new parameters to increase engine ITT temperature while in cruise. This is an imperfect adjustment, but the a/c will now run at approx. 600 C in cruise vs. 400+ in prior versions. This has no effect on handling or behavior other than to get a little closer to real world values. 

-Further adjustments to drag and thrust values to get ever closer to fidelity with Cessna test performance data for cruise at FL430. 

-Included a cameras.cfg file with a slightly higher default view point over the glareshield.


Version 1.51 Changes

-Modified thrust and drag curves to allow accurate fuel consumption for Mach cruise between M0.74 to M0.80, which is where the Longitude operates most efficiently. Fuel consumption is optimized for cruise at 43,000 feet at ISA conditions - fuel burn numbers are now within 1% of Cessna spec at FL430 for all speeds between M0.74 and M0.84 and for most weights and loadings. This required increasing ground idle N1 value (this has an effect on N1 and power curves) a bit above real world values and then subsequently reducing thrust at the new, higher ground idle N1 settings to avoid unrealistic engine thrust at idle and low N1 values during ground operations.  

-Engine N1 and N2 limits implemented (96.79% N1 and 98.62% N2 in ISA conditions). In essence this is a crude attempt at implmenting one small aspect of the FADEC system that controls Longitude engines. However, this has the further benefit of limiting aircraft N1 (and therefore available thrust) in a variety of conditions, more accurately representing how the aircraft performs IRL. Please note this does have the disadvantage of introducing significant "dead space" in upper throttle lever angle / throw range when at cruise and some slight "bobbling" of fuel flow when at or above maximum throttle is set. This has been added to the open items list. 

-Limited ITT to 955 C at max takeoff thrust at rest on the ground in ISA conditions. As a trade-off, this reduces maximum temperature while a/c in flight at maximum continuous thrust, which is a known vanilla issue within Asobo's turbine engine modeling.
-Adjusted center of gravity to more closely match real world figures and limits at various a/c weights and loadings.
-Adjusted Autopilot vertical speed hold to smooth autopilot commanded pitch changes.
-Adjusted autopilot altitude hold - reduced excursions from selected flight level while in cruise due to turbulence or other effects to within acceptable limits (+/- 65 ft of target altitude).
-Adjusted autothrottle speed hold - improved accuracy of autothrottle esp. during climbs - will now hold within 1 to 3 knots of target speed setting during climb and descent. Also reduced autothrottle induced hunting/surging behavior.
-Modified electrical bus tie to revert to default behavior (will be Off by default) to avoid problems with ground and APU power not working correctly when bus tie can't be closed.
-Increased intensity (brightness) of landing lights.
-White vertial stabilizer and belly beacon synchronized with wing and tail strobes.
-Reduced spoiler drag to a more realistic level.
-OnAir Virtual Airline compatible version included (must be installed in place of standard version if installation of OnAir compatible version desired - see installation notes below).


Version 1.42 Changes:

-Resolves issue caused by Asobo Dec 22, 2020 update to ai.cfg file that prevents NAV mode from properly holding course line and producing undesired left and right roll commands from autopilot while in NAV (and sometimes HDG) mode. 

Version 1.41 Changes:
-Updated to allow compatibility with Dec. 22, 2020 Asobo updates.

Version 1.4 Changes:
-All new exterior lighting upgrades from Uwajimaya including: 
	*Increased brightness/visibility of taxi and landing lights
	*Added separate volumetric landing lights to give reflections inside clouds without being overwhelming
	*Added alternating red/white beacon lights. In the real a/c, the white beacon is part of the recognition lights. Current FS2020 limitations prevent full real-life behavior of recognition and pulse lights.
	*Placed the source for the logo light on top of the engines rather than in the horizontal stabilizer.
	*Lighting enhancements files are included in the main install folder - no separate folder or installation needed.
-Improved approach and landing performance to be much closer to spec for all a/c landing weights. Vapp to 500 ft and Vref+3 (or higher) to Vref at 50 ft is now possible with a flat approach attitude. 
-Refinements to control force requirements (heavier) based on IRL pilot feedback.
-Further improved time to climb performance closer to IRL specs.
-Revisions and fixes to bring stall annunciation speeds to near spec in all flaps configurations.
-Reduced auto-throttle hunting / surging behavior during climb-out.
-Further refinements to fuel consumption / thrust / N1 adjustments at cruise altitudes - optimized to be within 1% of Cessna spec fuel burn at FL430 and ISA conditions between M0.8 and M0.84.
-Further improved ground handling during taxi and takeoff.
-Fixed exterior pilot avatar display issue.
-Fixed engine exhaust plume display issue.
-Other small fixes and adjustments.

Version 1.3 Changes:
-Fuel consumption / thrust / N1 adjustments to closer match real world performance tables.*
-Climb performance addressed - aircraft more closely matches real world climb performance at MTOW
-Restored tail logo lights omitted from prior version.
-Engine starters now automatically disengage once the engines are running
-Reduced rudder authority with increasing dynamic pressure and further improvements to rudder input / response
-Updated / simplified pfd tape readout (override of the default cockpit.cfg)
-Updated Aircraft variation in aircraft.cfg - will assist users with installation.**
-Adjusted flap drag performance - reduction in drag coefficient.
-Adjusted g-limits to spec for the type
-Increased landing light and taxi light intensity and throw distance (optional install).***

*A kind benefactor provided me with Cessna Longitude AFM and the tested / calculated engine performance data sheets that I've used to reference fuel burn, climb performance, and N1 settings among quite a few other reference values. Unfortunately, the underlying Asobo turbine engine modeling leaves a lot to be desired, but I’ve now spent a quite unreasonable amount of time working toward some more reasonable N1/thrust/fuel consumption figures that are much closer to the specs Cessna has tested and/or calculated, particularly at target cruise altitudes and ISA conditions. Annoyingly, and no matter what parameters I modify, the fuel burn in the cruise Mach range (0.78 to 0.84) is always significantly better at middle cruising altitudes (FL320 to FL390) than at higher altitudes (FL390 and above), definitely unlike the real-world aircraft, which really likes to be well above FL400 for best efficiency. It appears that the lapse rate for the turbine fuel consumption isn’t modeled correctly within the base Asobo simulation code and doesn’t correctly follow the lapse rate in available thrust with increasing altitude (which is a little off, but manageable in the .cfg files). In MSFS2020, as turbine aircraft climb they lose thrust, as they should, but the fuel consumption doesn’t drop requisitely. So, the fuel burn parameters must either be adjusted to favor low altitude realism or high altitude realism - but not both. To get reasonable approximations, I’ve used some “fudge” factors that Asobo added to the engines configurations file and made numerous fine adjustments to several engine parameters and drag/lift parameters, and while those help get the modeling closer, they can still create some odd and unrealistic performance results. This is not surprising given that, as of V1.4 publish date, Asobo have not seemingly focused on turbine aircraft performance fidelity to the degree they have piston engine aircraft. Bottom line: I’ve tuned the engine performance specs to be reasonably close to Cessna’s IRL figures for cruise at FL400 to FL450 (optimized for FL430). If anyone has found a magical coefficient somewhere in the engines.cfg file to properly model this fuel consumption lapse rate with altitude, please let me know!

Version 1.22 changes:
Interim fix to restore compatibility with Asobo update 7 on November 24 2020. Prior versions not compatible. 

Version 1.21 changes:
Interim fix to autopilot IAS hold limit and increases roll authority for autopilot. 

Version 1.2 changes:
-Simplified installation
-Compatible with other Longitude liveries
-Additional refinements to handling 
-Addressed issue with autorotation at takeoff trim setting
-Minor refinements to engine performance and fuel burn
-Updated autopilot limits and braking power
-Corrected issue with electrical bus tie - now shows always on when engines are running

Version 1.0 and 1.1 changes:
-Completely eliminated pitch and roll oscillations while using autopilot at all altitudes and airspeeds
-Corrected aicraft weights, fuel loads, payloads, etc...
-Increased number of payload stations to better approximate real-world
-Modified engine performance and fuel burn rates at cruise (burns b/w 1600 to 2000 pph at FL410 to FL440) 
-Reduction in overly sensitive pitch, roll, and yaw responses
-Closer approximation of takeoff, approach, landing, and stall speeds (clean and dirty)
-Generally improved handling at all altitudes and airspeeds
-Improved ground handling
-Added a tail / logo light missing from Asobo's original model.


//_________________________________________________________________________________________



Questions, comments, requests, suggestions - contact me on the Microsoft Flight Simulator 2020 official forum: dakfly0219

Special thanks to Uwajimaya for his excellent external lights update, JeffreyCobra for assitance with the install package testing and forum support, DiBarkis for his keen eye for Longitude visual and performance details and troubleshooting feedback, UnbilledLand644 for testing and feedback from real world experience, BanjoApocalypse for insights into the Longitude performance envelope, Dihedral977 for useful a/c performance documentation and test flying, Ahmad310X for Cessna Longitude official documentation and performance charts, GBTAW for finding a solution to the erroneous "landing gear" audible alert. Thanks to the flightsim community for all of the helpful comments, encouragement, and feedback, and of course to Asobo for developing an overall great product.


These files are provided for free, as is, with no warranty expressed or implied. These files are to be used only by users of properly licensed versions of the software which these files are intended to enhance or modify. No support is provided for these files. By downloading and using these files you agree to waive any rights to remedy for any damage to your computer systems, software, or user files that may be caused by your use or misuse of these software files. If you modify and repost or publish these files in the public domain, please credit the original author.